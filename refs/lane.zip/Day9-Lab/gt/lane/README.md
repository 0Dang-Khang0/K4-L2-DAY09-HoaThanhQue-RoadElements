Reference lane do người thiết kế lab vẽ theo card 1 trên 6 ảnh core, KHÔNG phải GT chính thức BDD100K. Khác reference chưa chắc là bạn sai: ghi who_is_right và lý do.
